##------------------------------------------------##
## Title:  Regression modelling tutorial
## Date:   Winter 2022
##
## Author: Philipp Ratz
## Email:  ratz.philipp@courrier.uqam.ca
##
## Descr:  Simple data exploration and model 
##         tuning to predict the death-rate of 
##         to cancer in the United States
##------------------------------------------------##

#### Setup ####
setwd("~/Documents/Uni/PhD/UQAM/teaching/STT5100/recap_linear_reg")
rm(list=ls())
library(tidyverse)

# Font setup (needs to have the Montserrat Font installed). It is available
# for free at https://fonts.google.com/specimen/Montserrat
# Otherwise change the fontspec to whatever you prefer (or leave it empty)
# your system will then just use your default font (on windows - often Arial)

global_theme <- function(){
  
  theme_minimal() %+replace%
    theme(
      text=element_text(family='Montserrat', size=14),
      axis.text = element_text(size=14), 
      plot.title = element_text(family='Montserrat SemiBold', size=18, hjust = 0.5),
      plot.subtitle = element_text(hjust = 0.5)
    )
}

#### Split ####

df_raw <- read_csv("cancer_reg.csv") %>% rowid_to_column('row_id')

set.seed(42)
df_raw %>%
  sample_frac(size=0.2, replace = FALSE) -> test_all

df_raw %>% 
  filter(!row_id %in% test_all$row_id) %>% 
  select(-c(row_id)) -> train_all

test_all %>% select(-c(TARGET_deathRate, row_id)) -> test_X
test_all %>% select(TARGET_deathRate) -> test_y

# You receive train_all and test_X

#### First Look ####


# Split Data
train_all %>% 
  rowid_to_column('train_id') -> train_all

set.seed(42)
train_all %>% 
  sample_frac(size=0.8,
              replace = FALSE) -> train
train_all %>% 
  filter(!train_id %in% train$train_id) -> validate

train %>% select(-c(train_id)) -> train
validate %>% select(-c(train_id)) -> validate

# Missing Data?
train %>%
  select(everything()) %>% 
  summarise_all(funs(sum(is.na(.)))) %>% 
  View()

train %>%
  select(everything()) %>% 
  summarise_all(funs(sum(is.na(.)))) %>% 
  gather() %>% 
  arrange(desc(value))

train %>% 
  select(contains('Pct'))

drop_potential <- c('PctSomeCol18_24', 'PctPrivateCoverageAlone', 'PctEmployed16_Over')

# How does my y look like?
train %>% 
  ggplot() + 
  geom_histogram(aes(x=TARGET_deathRate), fill='firebrick4', color='black') + 
  global_theme() + 
  ggtitle('Deathrate overview')

train %>% 
  ggplot() + 
  stat_ecdf(aes(x=TARGET_deathRate),
            geom='step', pad=F) + 
  global_theme() + 
  ggtitle('Empirical CDF')

qqnorm(train$TARGET_deathRate)
qqline(train$TARGET_deathRate)

qqnorm(log(train$TARGET_deathRate))
qqline(log(train$TARGET_deathRate))

# What kind of variables are there?
str(train)

# Income 
table(train$binnedInc)

# Geography
table(train$Geography)
# https://statisticsglobe.com/extract-substring-before-or-after-pattern-in-r

train %>% 
  select(Geography) %>% 
  mutate(state = sub(".*, ", "", Geography))

train %>% 
  bind_rows(validate) %>% 
  mutate(state = as.factor(sub(".*, ", "", Geography))) -> train_all

train_all %>% tail(nrow(validate)) -> validate
train_all %>% head(nrow(train)) -> train

# SAME for VALIDATE and TEST
test_X %>% 
  mutate(state = sub(".*, ", "", Geography)) -> test_X

table(train$state)
table(train$state) %>% length()

#### Exploratory Data Analysis ####
train %>% 
  select_if(is.numeric) -> numeric_columns

numeric_columns %>% 
  cor() %>% 
  as_tibble() %>% 
  mutate(variable_name = names(numeric_columns)) %>% 
  gather(variable_name_1, correlation, c(avgAnnCount:BirthRate)) %>% 
  ggplot() + 
  geom_tile(aes(x=variable_name, y=variable_name_1, fill=correlation),color='white') + 
  scale_fill_gradient2(low = "blue", high = "red", mid = "white", 
                       midpoint = 0, limit = c(-1,1), space = "Lab", 
                       name="Pearson\nCorrelation") + 
  coord_fixed() + 
  theme(axis.text.x = element_text(angle = 45, vjust = 1, 
                                   size = 12, hjust = 1)) + 
  xlab('') + 
  ylab('')

numeric_columns %>% 
  cor() %>% 
  as_tibble() %>% 
  mutate(variable_name = names(numeric_columns)) %>% 
  gather(variable_name_1, correlation, c(avgAnnCount:BirthRate)) %>% 
  mutate(abs_cor = abs(correlation)) %>% 
  arrange(desc(abs_cor)) %>% 
  filter(variable_name != variable_name_1) %>% 
  {.->> correlation_list} %>% 
  head(20)


df <- as.data.frame(numeric_columns)
Y = numeric_columns$TARGET_deathRate

for(i in names(numeric_columns)){
  plt <- ggplot(df, aes_string(x=i, y = Y)) +
    geom_point() + 
    global_theme() + 
    ggtitle(i)
  print(plt)
  Sys.sleep(2)
}

#### Basic Model ####
train %>% 
  select(-c(Geography)) -> kitchen_sink_regression

lin_model_kitchen <- lm(TARGET_deathRate ~ ., data=kitchen_sink_regression)

drop_potential

train %>% 
  select(-c(Geography, PctSomeCol18_24)) -> kitchen_sink_regression

lin_model_kitchen <- lm(TARGET_deathRate ~ .,
                        data=kitchen_sink_regression)

lin_model_kitchen %>% summary()

drop_potential

train %>% 
  select(-c(Geography,PctPrivateCoverageAlone,
            PctEmployed16_Over, PctSomeCol18_24)) -> kitchen_sink_regression

model_1 <- lm(TARGET_deathRate ~ .,
              data=kitchen_sink_regression)

model_1 %>% summary()

prediction_naive = mean(train$TARGET_deathRate)
prediction_model_1 = predict(model_1, newdata = validate)

# Better than naive?
(prediction_naive - validate$TARGET_deathRate)^2 %>% mean()
(prediction_model_1 - validate$TARGET_deathRate)^2 %>% mean()

#### Evaluation ####

kitchen_sink_regression %>%
  select(-c('TARGET_deathRate')) %>% 
  names() %>% 
  paste(collapse=' + ') -> string_variables

# Assumptions
plot(model_1)

hatvalues(model_1) %>% 
  as_tibble() %>% 
  mutate(id_name = names(hatvalues(model_1))) %>% 
  arrange(desc(value))

train %>% 
  rowid_to_column() %>% 
  filter(!rowid %in% c(669,679, 1889, 1771, 1066, 1261, 1243)) %>% 
  select(-c(rowid)) -> train


# Model Parameters
model_1 %>% 
  summary()

# Are States significant (jointly?)
logic_vector <- sapply(names(model_1$coefficients),
                       function(x) {grepl('state', x)})

hypotheses <- paste(names(model_1$coefficients)[logic_vector], '=0')
hypotheses

car::linearHypothesis(model_1,
                      hypotheses)

# What about coverages?

logic_vector <- sapply(names(model_1$coefficients),
                       function(x) {grepl('Coverage', x)})

hypotheses <- paste(names(model_1$coefficients)[logic_vector], '=0')
hypotheses

car::linearHypothesis(model_1,
                      hypotheses)

# Sanity Check: How are the effects of income?
model_1 %>% summary()

train$binnedInc %>% table()

#### Improvement Cycle ####

# Variables that we can transform?

train %>% 
  select_if(is.numeric) -> numeric_columns

df <- as.data.frame(numeric_columns)
Y = numeric_columns$TARGET_deathRate

for(i in names(numeric_columns)[1:5]){
  plt <- ggplot(df, aes_string(x=i, y = Y)) +
    geom_point() + 
    global_theme() + 
    ggtitle(i)
  print(plt)
  Sys.sleep(2)
}

ggplot(train) +
  geom_point(aes(x=log(avgAnnCount), y=TARGET_deathRate)) + 
  global_theme()

ggplot(train) +
  geom_point(aes(x=log(avgDeathsPerYear), y=TARGET_deathRate)) + 
  global_theme()

lm(TARGET_deathRate ~ avgDeathsPerYear, data=train) %>% summary()
lm(TARGET_deathRate ~ log(avgDeathsPerYear), data=train) %>% summary()
lm(TARGET_deathRate ~ log(avgDeathsPerYear) + I(log(avgDeathsPerYear)^2), data=train) %>% summary()
lm(TARGET_deathRate ~ avgDeathsPerYear + avgDeathsPerYear^2, data=train) %>% summary()

lm(TARGET_deathRate ~ log(avgDeathsPerYear) + I(log(avgDeathsPerYear)^2), data=train) -> check_mod_1
predict(check_mod_1) -> predictions_check_1

train %>% 
  mutate(preds_nonlin = predictions_check_1) %>% 
  ggplot() + 
  geom_point(aes(x=log(avgDeathsPerYear), y=TARGET_deathRate)) + 
  geom_point(aes(x=log(avgDeathsPerYear), y=preds_nonlin), color='red') + 
  global_theme()

# Input: Now you might understand why we need transformations - 
# All the new methods (aka. Machine Learning) were based on having many 
# transformations and then finding which ones are relevant!


# Do we really need all the states?
# Maybe some larger regional differences?
# Google: "group us states into regions data"
# Find: https://github.com/cphalpert/census-regions/blob/master/us%20census%20bureau%20regions%20and%20divisions.csv
grouping_states <- read_csv("grouping_states.csv")
grouping_states %>% head()

unique(train$state) %in% grouping_states$State

train %>% 
  left_join(grouping_states, 
            by=c('state'='State')) -> train

lm(TARGET_deathRate ~ state, data=train) %>% summary()
lm(TARGET_deathRate ~ Region, data=train) %>% summary()
lm(TARGET_deathRate ~ Division, data=train) %>% summary()

lm(all_formula, data=train) %>% summary()

string_variables
region_formula <- as.formula('TARGET_deathRate ~avgAnnCount + avgDeathsPerYear+ incidenceRate + medIncome +
                             popEst2015 + povertyPercent + studyPerCap +
                             binnedInc + MedianAge + MedianAgeMale + MedianAgeFemale +
                             AvgHouseholdSize + PercentMarried + PctNoHS18_24 +
                             PctHS18_24 + PctBachDeg18_24 + PctHS25_Over +
                             PctBachDeg25_Over + PctUnemployed16_Over + PctPrivateCoverage +
                             PctEmpPrivCoverage + PctPublicCoverage + PctPublicCoverageAlone +
                             PctWhite + PctBlack + PctAsian + PctOtherRace +
                             PctMarriedHouseholds + BirthRate + Region')

lm(region_formula, data=train) %>% summary()

BIC(lm(all_formula, data=train))
BIC(lm(region_formula, data=train))

# Variables are fixed, but still too many?
corrected_string <- 'log(avgAnnCount) + I(log(avgAnnCount)^2) +
                     log(avgDeathsPerYear) + I(log(avgDeathsPerYear)^2) + 
                     incidenceRate + medIncome + I(medIncome^2) + 
                     popEst2015 + povertyPercent + studyPerCap + binnedInc +
                     MedianAge + MedianAgeMale + MedianAgeFemale +
                     AvgHouseholdSize + PercentMarried + PctNoHS18_24 +
                     PctHS18_24 + PctBachDeg18_24 + PctHS25_Over + PctBachDeg25_Over +
                     PctUnemployed16_Over + PctPrivateCoverage + PctEmpPrivCoverage +
                     PctPublicCoverage + PctPublicCoverageAlone + PctWhite + PctBlack +
                     PctAsian + PctOtherRace + PctMarriedHouseholds + BirthRate +
                     Region'

new_formula_complete <- as.formula(paste('TARGET_deathRate ~ ', corrected_string))
complete_model_corrected <- lm(new_formula_complete, data=train)
complete_model_corrected %>% summary()


2^(dim(train)[2]-1)
# Model Selection Stepwise
validate %>% 
  left_join(grouping_states, 
            by=c('state'='State')) -> validate

# Stepwise regression model
constant <- lm(TARGET_deathRate ~ 1, data=train)

stepwise_selection_aic <- step(constant,
                               scope = list(lower=constant,upper=complete_model_corrected),
                               direction="both")

stepwise_selection_bic <- step(constant,
                               scope = list(lower=constant,upper=complete_model_corrected),
                               direction="both", k=log(nrow(train)))

stepwise_selection_aic %>% summary()
stepwise_selection_bic %>% summary()

# Again, this goes to the core of what (modern statistics is all about)
# you need to find a metric that is objectively the best, understand 
# why you are modelling *what* in a certain way and then let the machine choose
# your best model

#### Predictive Performance ####

AIC(stepwise_selection_aic)
AIC(model_1)

BIC(stepwise_selection_bic)
BIC(model_1)

summary(stepwise_selection_aic)$r.squared
summary(stepwise_selection_bic)$r.squared
summary(model_1)$r.squared

# Forecasting
prediction_tuned_aic <- predict(stepwise_selection_aic, newdata = validate)
prediction_tuned_bic <- predict(stepwise_selection_bic, newdata = validate)

(prediction_naive - validate$TARGET_deathRate)^2 %>% mean()
(prediction_model_1 - validate$TARGET_deathRate)^2 %>% mean()
(prediction_tuned_bic - validate$TARGET_deathRate)^2 %>% mean()
(prediction_tuned_aic - validate$TARGET_deathRate)^2 %>% mean()

#https://www.kaggle.com/c/ubiquant-market-prediction/leaderboard
plot(stepwise_selection_aic)

# Edge Cases
tibble(
  predictions = prediction_tuned_aic, 
  true_value = validate$TARGET_deathRate, 
) %>% 
  mutate(
    error_ = true_value - predictions
  ) %>% 
  mutate(
    abs_error = abs(error_)
  ) %>% 
  mutate(
    mean_value = mean(true_value), 
    median_value = median(true_value), 
    q_90 = quantile(true_value, 0.9), 
    q_10 = quantile(true_value, 0.1)) %>% 
  mutate(
    diff_to_mean = abs(true_value - mean_value), 
  ) %>% 
  arrange(desc(abs_error)) -> error_stats_

error_stats_

error_stats_ %>% 
  mutate(under_over = if_else(error_ < 0, 'overprediction', 'underprediction')) %>% 
  ggplot() + 
  geom_point(aes(x=diff_to_mean, y=abs_error, color=under_over)) + 
  geom_smooth(aes(x=diff_to_mean, y=abs_error), 
            se=F, color='black', lty='dashed') + 
  global_theme() + 
  scale_color_manual(values=c('coral3', 'dodgerblue4')) +
  ggtitle('Errors and position in distribution') + 
  theme(legend.title = element_blank()) + 
  xlab('Absolute difference to mean') + 
  ylab('Absolute prediction error')
