#### Model Curve ####
true_y <- test$target
binary_prediction = if_else(predicted_probas > 0.5, 1, 0)

tibble(y = true_y, 
       y_hat = binary_prediction, 
       proba = predicted_probas) -> data_calc

data_calc %>% head() %>% kable()

TP = data_calc %>% filter(y == 1 & y_hat == 1) %>% nrow()
FP = data_calc %>% filter(y == 0 & y_hat == 1) %>% nrow()
FN = data_calc %>% filter(y == 1 & y_hat == 0) %>% nrow()
TN = data_calc %>% filter(y == 0 & y_hat == 0) %>% nrow()

TPR = TP/(TP + FN)
FPR = FP/(FP + TN)

plot(FPR, TPR, 
     xlim=c(0,1), 
     ylim=c(0,1), col='black')


true_y <- test$target
binary_prediction = if_else(predicted_probas > 0.8, 1, 0)

tibble(y = true_y, 
       y_hat = binary_prediction, 
       proba = predicted_probas) -> data_calc

data_calc %>% head() %>% kable()

TP = data_calc %>% filter(y == 1 & y_hat == 1) %>% nrow()
FP = data_calc %>% filter(y == 0 & y_hat == 1) %>% nrow()
FN = data_calc %>% filter(y == 1 & y_hat == 0) %>% nrow()
TN = data_calc %>% filter(y == 0 & y_hat == 0) %>% nrow()

TPR = TP/(TP + FN)
FPR = FP/(FP + TN)
points(FPR, TPR, col='red')



true_y <- test$target
binary_prediction = if_else(predicted_probas > 0.1, 1, 0)

tibble(y = true_y, 
       y_hat = binary_prediction, 
       proba = predicted_probas) -> data_calc

data_calc %>% head() %>% kable()

TP = data_calc %>% filter(y == 1 & y_hat == 1) %>% nrow()
FP = data_calc %>% filter(y == 0 & y_hat == 1) %>% nrow()
FN = data_calc %>% filter(y == 1 & y_hat == 0) %>% nrow()
TN = data_calc %>% filter(y == 0 & y_hat == 0) %>% nrow()

TPR = TP/(TP + FN)
FPR = FP/(FP + TN)
points(FPR, TPR, col='green')


for (threshold in seq(0,1,0.01)){
  true_y <- test$target
  binary_prediction = if_else(predicted_probas > threshold, 1, 0)
  
  tibble(y = true_y, 
         y_hat = binary_prediction, 
         proba = predicted_probas) -> data_calc
  
  data_calc %>% head() %>% kable()
  
  TP = data_calc %>% filter(y == 1 & y_hat == 1) %>% nrow()
  FP = data_calc %>% filter(y == 0 & y_hat == 1) %>% nrow()
  FN = data_calc %>% filter(y == 1 & y_hat == 0) %>% nrow()
  TN = data_calc %>% filter(y == 0 & y_hat == 0) %>% nrow()
  
  TPR = TP/(TP + FN)
  FPR = FP/(FP + TN)
  points(FPR, TPR, col='blue')
}


rocr_obj <- ROCR::prediction(predicted_probas, test$target)
auc_inst <- ROCR::performance(rocr_obj,
                              measure = "auc")
roc_inst <- ROCR::performance(rocr_obj,
                              measure = "tpr", x.measure = "fpr")

plot(roc_inst)
text(0.8,0.5,paste("AUC = ",format(auc_inst@y.values[[1]], digits=3, scientific=FALSE)))

for (threshold in seq(-.0001,1.0001,0.01)){
  true_y <- test$target
  binary_prediction = if_else(predicted_probas > threshold, 1, 0)
  
  tibble(y = true_y, 
         y_hat = binary_prediction, 
         proba = predicted_probas) -> data_calc
  
  data_calc %>% head() %>% kable()
  
  TP = data_calc %>% filter(y == 1 & y_hat == 1) %>% nrow()
  FP = data_calc %>% filter(y == 0 & y_hat == 1) %>% nrow()
  FN = data_calc %>% filter(y == 1 & y_hat == 0) %>% nrow()
  TN = data_calc %>% filter(y == 0 & y_hat == 0) %>% nrow()
  
  TPR = TP/(TP + FN)
  FPR = FP/(FP + TN)
  points(FPR, TPR, col='blue')
}

#### Naive Curve ####

## All zero
true_y <- test$target
binary_prediction = 0

tibble(y = true_y, 
       y_hat = binary_prediction, 
       proba = predicted_probas) -> data_calc


TP = data_calc %>% filter(y == 1 & y_hat == 1) %>% nrow()
FP = data_calc %>% filter(y == 0 & y_hat == 1) %>% nrow()
FN = data_calc %>% filter(y == 1 & y_hat == 0) %>% nrow()
TN = data_calc %>% filter(y == 0 & y_hat == 0) %>% nrow()

TPR = TP/(TP + FN)
FPR = FP/(FP + TN)
points(FPR, TPR, col='red', pch = 15)


## All 1
true_y <- test$target
binary_prediction = 1

tibble(y = true_y, 
       y_hat = binary_prediction, 
       proba = predicted_probas) -> data_calc


TP = data_calc %>% filter(y == 1 & y_hat == 1) %>% nrow()
FP = data_calc %>% filter(y == 0 & y_hat == 1) %>% nrow()
FN = data_calc %>% filter(y == 1 & y_hat == 0) %>% nrow()
TN = data_calc %>% filter(y == 0 & y_hat == 0) %>% nrow()

TPR = TP/(TP + FN)
FPR = FP/(FP + TN)
points(FPR, TPR, col='red', pch = 15)

## Random (convex combination)

true_y <- test$target

#for (i in c(1:length(true_y))){
i=1
  binary_prediction = c(rep(1,i),
                        rep(0, (length(true_y) - i)))
  
  tibble(y = true_y,
#         y = sample(true_y, length(true_y)),
         y_hat = binary_prediction, 
         proba = predicted_probas) -> data_calc
  
  TP = data_calc %>% filter(y == 1 & y_hat == 1) %>% nrow()
  FP = data_calc %>% filter(y == 0 & y_hat == 1) %>% nrow()
  FN = data_calc %>% filter(y == 1 & y_hat == 0) %>% nrow()
  TN = data_calc %>% filter(y == 0 & y_hat == 0) %>% nrow()
  
  TPR = TP/(TP + FN)
  FPR = FP/(FP + TN)
  points(FPR, TPR, col='red', pch = 15)
#}

abline(a=0, b=1, col="black")

#### Tree interpretation ####
plot(roc_inst)

## Stump predictors
min_ <- data_classification$`worst texture` %>% min()
max_ <- data_classification$`worst texture` %>% max()
train$target %>% table()

for (cut_off in seq(min_, max_, 1)){
  binary_prediction = if_else(test$`worst texture` > cut_off, 0, 1)
  
  tibble(y = true_y,
         y_hat = binary_prediction, 
         proba = predicted_probas) -> data_calc
  
  TP = data_calc %>% filter(y == 1 & y_hat == 1) %>% nrow()
  FP = data_calc %>% filter(y == 0 & y_hat == 1) %>% nrow()
  FN = data_calc %>% filter(y == 1 & y_hat == 0) %>% nrow()
  TN = data_calc %>% filter(y == 0 & y_hat == 0) %>% nrow()
  
  TPR = TP/(TP + FN)
  FPR = FP/(FP + TN)
  points(FPR, TPR, col='green', pch = 15)
}

min_ <- data_classification$`mean fractal dimension` %>% min()
max_ <- data_classification$`mean fractal dimension` %>% max()

for (cut_off in seq(min_, max_, 0.005)){
  binary_prediction = if_else(test$`mean fractal dimension` > cut_off, 1, 0)
  
  tibble(y = true_y,
         y_hat = binary_prediction, 
         proba = predicted_probas) -> data_calc
  
  TP = data_calc %>% filter(y == 1 & y_hat == 1) %>% nrow()
  FP = data_calc %>% filter(y == 0 & y_hat == 1) %>% nrow()
  FN = data_calc %>% filter(y == 1 & y_hat == 0) %>% nrow()
  TN = data_calc %>% filter(y == 0 & y_hat == 0) %>% nrow()
  
  TPR = TP/(TP + FN)
  FPR = FP/(FP + TN)
  points(FPR, TPR, col='blue', pch = 15)
}

abline(a=0, b=1, col="black")

