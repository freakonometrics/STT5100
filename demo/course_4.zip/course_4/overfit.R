rm(list=ls())
library(tidyverse)

#### Linear Case ####

linear_noise <- function(){
  set.seed(42)
  noise_vec <- rnorm(61,0,2)
  x = seq(-3,3, 0.1)
  y = 1 + 2*x + noise_vec
  
  return(list('x'=x, 
              'y'=y))
}

data_linear <- linear_noise()
idx_train <- sort(sample(seq(1,61), 40))
idx_test <- sort(which(!seq(1,61) %in% idx_train))

train = tibble(
  x=data_linear$x[idx_train], 
  y=data_linear$y[idx_train]
)

test = tibble(
  x=data_linear$x[idx_test], 
  y=data_linear$y[idx_test]
)

mod_linear <- lm(y ~ x, data=train)
fit_linear_simple <- predict(mod_linear)

mod_linear %>% summary()

plot(train$x, train$y)
abline(a=1, b=2, col='black', lwd=3)
lines(train$x, 
      fit_linear_simple, 
      col='red', 
      lwd=2)

mod_linear_poly <- lm(y ~ poly(x,50,raw=T), data=train)
summary(mod_linear_poly)

lines(train$x, 
      predict(mod_linear_poly),
       type='l' ,
       col='blue', 
       lty=2, 
       lwd=2)

predictons_simple <- predict(mod_linear,
                             newdata = test)

predictions_complex = predict(mod_linear_poly, 
                              newdata = test)

mod_linear$residuals^2 %>% sum()
mod_linear_poly$residuals^2 %>% sum()

mean((predictons_simple - test$y)^2)
mean((predictions_complex - test$y)^2)


plot(test$x, test$y)
abline(a=1, b=2, col='black', lwd=3)
lines(train$x, 
      predict(mod_linear_poly),
      type='l' ,
      col='blue', 
      lty=2, 
      lwd=2)


#### Nonlinear case ####

nonlinear_noise <- function(){
  set.seed(42)
  noise_vec <- rnorm(61,0,2)
  x = seq(-3,3, 0.1)
  y = 1 + x + 1.8*x^2 - 0.1*x^3 + noise_vec
  
  return(list('x'=x, 
              'y'=y))
}

data_linear <- nonlinear_noise()
idx_train <- sort(sample(seq(1,61), 40))
idx_test <- sort(which(!seq(1,61) %in% idx_train))

train = tibble(
  x=data_linear$x[idx_train], 
  y=data_linear$y[idx_train]
)

test = tibble(
  x=data_linear$x[idx_test], 
  y=data_linear$y[idx_test]
)

mod_linear <- lm(y ~ x, data=train)
fit_linear_simple <- predict(mod_linear)

mod_linear %>% summary()

plot(train$x, train$y)

x_ = seq(-3,3,0.01)
y_ = 1 + x_ + 1.8*x_^2 - 0.1*x_^3

lines(x_, y_, col='black', lwd=2)
lines(train$x, 
      fit_linear_simple, 
      col='red', 
      lwd=2)

mod_linear_poly <- lm(y ~ poly(x,5,raw=T), data=train)
summary(mod_linear_poly)

lines(train$x, 
      predict(mod_linear_poly),
      type='l' ,
      col='blue', 
      lty=2, 
      lwd=2)

predictons_simple <- predict(mod_linear,
                             newdata = test)

predictions_complex = predict(mod_linear_poly, 
                              newdata = test)

mean((predictons_simple - test$y)^2)
mean((predictions_complex - test$y)^2)


