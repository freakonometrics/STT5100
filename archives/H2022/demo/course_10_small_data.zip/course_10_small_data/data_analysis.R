##--------------------------------------------------------##
## Title:  Binary regression modelling tutorial
## Date:   Winter 2022
##
## Author: Philipp Ratz
## Email:  ratz.philipp@courrier.uqam.ca
##
## Descr:  Simple data exploration and model adjustment
##         to predict accident probabilities on personal
##         vehicle insurance data
##
## Note:   The whole dataset is too large to post on 
##         GitHub, I added a sample instead (the code
##         will still run but you might get different
##         conclusions based on the sample)
##--------------------------------------------------------##

#### Setup ####

# Same as seen before..
setwd("~/Documents/Uni/PhD/UQAM/teaching/STT5100/course_10/")
rm(list=ls())

library(tidyverse)
library(knitr)
library(rpart)
library(rpart.plot)
library(ROCR)

# Font setup (needs to have the Montserrat Font installed). It is available
# for free at https://fonts.google.com/specimen/Montserrat
# Otherwise change the fontspec to whatever you prefer (or leave it empty)
# your system will then just use your default font (on windows - often Arial)

global_theme <- function(){
  
  theme_minimal() %+replace%
    theme(
      text=element_text(family='Montserrat', size=14),
      axis.text = element_text(size=14), 
      plot.title = element_text(family='Montserrat SemiBold', size=18, hjust = 0.5),
      plot.subtitle = element_text(hjust = 0.5)
    )
}

#### Split ####

load('./insurance_data_all.Rda')

data_all %>% 
  sample_n(10000) -> sample_data

save(sample_data, file='./sample_data.Rda')

# There is usually an inherent hierarchy
data_all %>%
  select(contains('id')) %>% 
  summarise_all(n_distinct)

data_all %>% 
  select(contains('id')) %>% 
  group_by(client_id) %>% 
  summarise_all(n_distinct) %>% 
  arrange(desc(policy_id))

data_all %>% 
  select(contains('id')) %>% 
  group_by(client_id) %>% 
  summarise_all(n_distinct) %>% 
  arrange(desc(location_id))

all_ids <- unique(data_all$client_id)
sampled_ids <- sample(all_ids, size=floor(0.7*nrow(data_all)))

data_all %>% 
  filter(client_id %in% sampled_ids) -> train

data_all %>% 
  filter(!client_id %in% sampled_ids) -> test

#### First Look ####

train %>% 
  head()

train %>% 
  str()

# Inherent hierarchy also in the data..
train %>% 
  select(drv_drv2, drv_age2, drv_sex2) %>%
  head()

train %>% 
  summarise_all(funs(sum(is.na(.)))) %>% 
  gather() %>%
  View()

train$target_accident %>% table()

#### Exploratory Data Analysis ####

## What does our y look like?
train %>% 
  mutate(target_accident = as.factor(target_accident)) %>% 
  group_by(target_accident) %>% 
  summarise(totals = n()) %>% 
  mutate(fraction = totals / sum(totals)) %>% 
  ggplot() + 
  geom_bar(aes(x=target_accident, 
               y=fraction), 
           stat='identity', 
           color='black', 
           fill='firebrick4') + 
  global_theme() + 
  scale_y_continuous(labels=scales::percent) + 
  scale_x_discrete(labels = c('None', 'Has accident')) + 
  xlab('')

baseline_prediction = rep(mean(train$target_accident), 
                          nrow(test))

train %>% 
  head() %>% 
  View()

# Bonus is usually a very good indicator
# together with years
train %>% 
  select(pol_bonus, pol_duration) %>% 
  ggplot() + 
  geom_point(aes(x=pol_duration,
                 y=pol_bonus)) + 
  global_theme()

train %>% 
  arrange(target_accident) %>% 
  select(pol_bonus, pol_duration, target_accident) %>% 
  mutate(target_accident = as.factor(target_accident)) %>% 
  ggplot() + 
  geom_point(aes(x=pol_duration,
                 y=pol_bonus, 
                 color=target_accident)) + 
  geom_smooth(aes(x=pol_duration,
                  y=pol_bonus, 
                  color=target_accident)) +
  global_theme()


train %>% 
  group_by(pol_coverage) %>% 
  summarise(
    total = mean(target_accident)
  ) %>% 
  ggplot() + 
  geom_bar(aes(x=pol_coverage, 
               y=total), 
           stat='identity', 
           color='black', 
           fill='firebrick4') + 
  global_theme() + 
  scale_y_continuous(labels=scales::percent) 

train %>% 
  select(pol_coverage, target_accident) %>% 
  table() %>%
  prop.table() %>% 
  kable()

train %>% 
  select(pol_coverage, target_accident) %>% 
  table() %>%
  prop.table(margin = 1) %>% 
  kable()

train %>% 
  select(pol_coverage, target_accident) %>% 
  table() %>%
  prop.table(margin = 2) %>% 
  kable()


## Fill in missing values
train %>% 
  summarise_all(funs(sum(is.na(.)))) %>% 
  gather() %>% 
  arrange(desc(value))

train %>% 
  filter(is.na(vh_age)) %>% 
  View()

train %>% 
  mutate(vh_age = if_else(is.na(vh_age),
                          mean(train$vh_age),
                          vh_age)) -> train

test %>% 
  mutate(vh_age = if_else(is.na(vh_age),
                          mean(train$vh_age),
                          vh_age)) -> test

train %>% 
  select(contains('2'))

train %>% 
  mutate(check_second_driver = if_else(is.na(drv_sex2), 'N', drv_sex2)) %>% 
  select(check_second_driver, target_accident) %>% 
  table() %>% 
  prop.table(margin = 1) %>% 
  kable()

train %>% 
  mutate(check_second_driver = if_else(is.na(drv_sex2), 'N', drv_sex2)) %>% 
  ggplot() + 
  geom_jitter(aes(x=check_second_driver, 
               y=drv_age2), 
           stat='identity', 
           color='black', 
           fill='firebrick4') + 
  global_theme()

train %>% 
  mutate(has_second_driver = if_else(is.na(drv_sex2), 1, 0)) -> train

test %>% 
  mutate(has_second_driver = if_else(is.na(drv_sex2), 1, 0)) -> test


#### First Model ####
train %>% 
  select(where(is.character)) %>% 
  summarise_all(funs(n_distinct(.))) %>% 
  gather() %>% 
  arrange(desc(value))

train %>% 
  select(where(is.character)) %>% 
  summarise_all(funs(n_distinct(.))) %>% 
  gather() %>% 
  filter(value > 4) %>% 
  pull(key) -> drop_vars
  

train %>% 
  select(-c(drop_vars)) %>% 
  select(-c(drv_sex2)) %>% 
  select(-c(has_second_driver)) -> data_model_1

model_1 <- glm(target_accident ~ ., 
               data = data_model_1)

model_1 %>% 
  summary()

# Analysis
1-pchisq(8987.2-8830.8, 76475-76445)

# Restrictions
train %>% 
  select(-c(drop_vars)) %>% 
  select(-c(drv_sex2)) %>% 
  select(-c(has_second_driver)) %>% 
  select(-c(vh_fuel))-> data_model_1_restricted

model_1_restricted <- glm(target_accident ~ .,
                          data = data_model_1_restricted)

model_1_restricted %>% summary()

1-pchisq(8838.6-8830.8, 2)

#### Adjustments ####

# Fuel regrouping
train$vh_fuel %>% table()

tree <- rpart(target_accident ~ vh_fuel,
              data = train,
              cp=1e-4)
prp(tree, type = 2, extra = 1)

train %>% 
  mutate(fuel_dummy = if_else(vh_fuel=='Gasoline', 1, 0)) -> train

test %>% 
  mutate(fuel_dummy = if_else(vh_fuel=='Gasoline', 1, 0)) -> test

# Too many factors
tree <- rpart(target_accident ~ vh_make,
              data = train,
              cp=1e-3)

prp(tree, type = 2, extra = 1)

predict(tree) %>% table()

train %>% 
  mutate(
    brand_dummy = predict(tree)
  ) %>% 
  mutate(brand_dummy = if_else(brand_dummy > 0.14, 1, 0)) -> train

predict(tree, newdata = test)

train_alt <- train %>% select(vh_make, client_id, target_accident) %>%
  bind_rows(test %>% 
              select(vh_make, client_id)) %>% 
  mutate(vh_make = as.factor(vh_make))

train_alt %>% 
  head(nrow(train)) -> train_alt

tree <- rpart(target_accident ~ vh_make,
              data = train_alt,
              cp=1e-3)

prp(tree, type = 2, extra = 1)

predict(tree, newdata = test)

test %>% 
  mutate(
    brand_dummy = predict(tree, newdata = test)
  ) %>% 
  mutate(brand_dummy = if_else(brand_dummy > 0.14, 1, 0)) -> test

train %>% 
  mutate(
    drv_sex2 = if_else(is.na(drv_sex2), 'N', drv_sex2)
  ) -> train

test %>% 
  mutate(
    drv_sex2 = if_else(is.na(drv_sex2), 'N', drv_sex2)
  ) -> test

# Location

train_alt <- train %>% select(vh_make, location_id, target_accident) %>%
  bind_rows(test %>% 
              select(vh_make, location_id)) %>% 
  mutate(vh_make = as.factor(vh_make))

train_alt %>% 
  head(nrow(train)) -> train_alt

tree <- rpart(target_accident ~ location_id,
              data = train,
              cp=0.4)

prp(tree, type = 2, extra = 1)


## Model Fit
# Takes a while..
#car::residualPlots(model_1)

car::influencePlot(model_1)


train %>% 
  mutate(cooks_ = stats::cooks.distance(model_1)) %>% 
  arrange(desc(cooks_)) %>% View()

#### Second Model ####

train %>% 
  select(-contains('_id')) %>% 
  select(-c(vh_make, vh_model, vh_fuel)) -> transformed_data

transformed_data %>% 
  drop_na() -> transformed_data

test %>% 
  select(-contains('_id')) %>% 
  select(-c(vh_make, vh_model, vh_fuel)) %>% 
  drop_na()-> transformed_data_test

y_ <- transformed_data$target_accident
database <- transformed_data %>% select(-c(target_accident))

y_t <- test$target_accident
database_test <- transformed_data_test %>% select(-c(target_accident))

f <- as.formula(y_ ~ .)
y_ <- as.matrix(y_)
x <- model.matrix(f,database)[,-1]

x %>% as_tibble() %>% 
  mutate(interaction_age_sex_2 = drv_sex2N*drv_age2) %>%
  add_column(target_ = transformed_data$target_accident) -> final_train

f.1 <- as.formula(y_t ~ .)
y_t <- as.matrix(y_t)
x_test <- model.matrix(f.1, database_test)[,-1]

x_test %>% as_tibble() %>% 
  mutate(interaction_age_sex_2 = drv_sex2N*drv_age2) -> x_test

model_aic <- glm(target_ ~.,
                 data=final_train,
             family = binomial) %>%
  MASS::stepAIC(trace = TRUE)

save(model_aic, file='./model_aic.Rda')
load('./model_aic.Rda')

model_aic %>% summary()

#### Evaluation ####

# First - predictions
predictions_naive <- baseline_prediction
predictions_model1 <- predict(model_1, newdata = test)
predictions_model2 <- predict(model_aic, newdata = x_test)

p <- predict(cvfit, newx = nx, s = "lambda.min", type = "response")

obj_0 <- prediction(predictions_naive, test$target_accident)
auc <- performance(obj_0, measure = "auc")
auc_naive <- auc@y.values[[1]]

obj_1 <- prediction(predictions_model1, test$target_accident)
auc <- performance(obj_1, measure = "auc")
auc_model1 <- auc@y.values[[1]]

obj_2 <- prediction(predictions_model2, test$target_accident)
auc <- performance(obj_2, measure = "auc")
auc_model2 <- auc@y.values[[1]]

roc_1 <- performance(obj_1, measure = "tpr", x.measure= "fpr")
roc_2 <- performance(obj_2, measure = "tpr", x.measure= "fpr")

plot(roc_1)
plot(roc_2)

tibble(
  x_1 = unlist(roc_1@x.values)[-c(1,2,3)],
  x_2 = unlist(roc_2@x.values),
  y_1 = unlist(roc_1@y.values)[-c(1,2,3)],
  y_2 = unlist(roc_2@y.values),
) %>%
  ggplot() + 
  geom_line(aes(x=x_1, y=y_1), color='red') + 
  geom_line(aes(x=x_2, y=y_2), color='blue') +
  geom_abline(slope=1, intercept = 0) +
  global_theme() +
  ggtitle('Comparison ROC Curve')
