rm(list=ls())
library(tidyverse)

df_raw <- read_csv("cancer_reg.csv") %>%
    rowid_to_column('row_id') %>% 
  select_if(is.numeric) %>% 
  as.data.frame()

mark_outliers <- function(x_vector, standard_dev=2){
  ## Adjust standard_dev according to you needs
  ## You can apply this to a whole data frame
  ## so you do not need find outliers with a graph (as below)
  sd_s <- sqrt(var(x_vector, na.rm = T))
  me_s <- median(x_vector, na.rm = T)
  
  x_vector[is.na(x_vector)] <- me_s
  
  ret_vec <- if_else(x_vector > me_s + standard_dev*sd_s, 1, 0)
  return(ret_vec)
}

outlier_df <- as.data.frame(lapply(df_raw, FUN=mark_outliers))
outlier_df

# As seen during lecture:
# eg: MedianAge: Median age of county residents (b):

df_raw %>% 
  mutate(calculated_outliers = outlier_df$MedianAge) %>% 
  ggplot(aes(x=MedianAge, y=TARGET_deathRate)) +
  geom_point() + 
  theme_minimal()

# All outliers are correctly flagged
df_raw %>% 
  mutate(calculated_outliers = as.factor(outlier_df$MedianAge)) %>% 
  ggplot(aes(x=MedianAge, y=TARGET_deathRate, color=calculated_outliers)) +
  geom_point() + 
  theme_minimal()